---@diagnostic disable: lowercase-global, undefined-global
obs = obslua

-- Global variables for folder selection and user inputs
local folderPath = ""
local imageSources = {"Intro Image", "Webcam Image", "Outro Image", "JUXT Logo", "XTDB Logo"}
local cameraSources = {"Camera (Linux & Windows)", "Camera (Mac & Windows)"}
local maskFile = "Rounded.png"
local textSources = {"Main Title", "Sub Title", "Name", "Job Title"}
local textInputs = {"", "", "", ""}
local juxtLogo = "JUXT Logo"   -- Correct source name for JUXT logo
local xtdbLogo = "XTDB Logo"   -- Correct source name for XTDB logo

-- Function to switch to the JUXT scene collection
function switchToJUXTCollection()
    if obs.obs_frontend_get_current_scene_collection() ~= "JUXT" then
        obs.obs_frontend_set_current_scene_collection("JUXT")
    end
end

-- Function to update image sources with images from the selected folder
function updateImageSources()
    for _, image in ipairs(imageSources) do
        local imageSource = obs.obs_get_source_by_name(image)
        if imageSource then
            local settings = obs.obs_source_get_settings(imageSource)
            obs.obs_data_set_string(settings, "file", folderPath .. "/" .. image .. ".png")
            obs.obs_source_update(imageSource, settings)
            obs.obs_data_release(settings)
            obs.obs_source_release(imageSource)
        end
    end
end

-- Function to apply Image Mask/Blend filter to camera sources
function applyRoundingToCamera()
    local maskPath = folderPath .. "/" .. maskFile
    for _, camera in ipairs(cameraSources) do
        local cameraSource = obs.obs_get_source_by_name(camera)
        if cameraSource then
            local filter = obs.obs_source_get_filter_by_name(cameraSource, "Image Mask/Blend")
            if not filter then
                local settings = obs.obs_data_create()
                obs.obs_data_set_string(settings, "image_path", maskPath)
                obs.obs_data_set_string(settings, "type", "alpha_mask_alpha_channel") -- Apply alpha channel mask
                local newFilter = obs.obs_source_create("mask_filter", "Image Mask/Blend", settings, nil)
                obs.obs_source_filter_add(cameraSource, newFilter)
                obs.obs_data_release(settings)
                obs.obs_source_release(newFilter)
            else
                -- Update existing filter
                local settings = obs.obs_source_get_settings(filter)
                obs.obs_data_set_string(settings, "image_path", maskPath)
                obs.obs_source_update(filter, settings)
                obs.obs_data_release(settings)
                obs.obs_source_release(filter)
            end
            obs.obs_source_release(cameraSource)
        end
    end
end

-- Function to update text sources based on user input and set font size
function updateText()
    local fontSizes = {225, 200, 170, 170} -- Font sizes for Title, Subtitle, Name, Job Title

    for i, text in ipairs(textSources) do
        local textSource = obs.obs_get_source_by_name(text)
        if textSource then
            local settings = obs.obs_source_get_settings(textSource)

            -- Set the text content
            obs.obs_data_set_string(settings, "text", textInputs[i])

            -- Set the font properties
            local fontSettings = obs.obs_data_get_obj(settings, "font")
            if fontSettings then
                obs.obs_data_set_int(fontSettings, "size", fontSizes[i])
                obs.obs_data_set_obj(settings, "font", fontSettings)
                obs.obs_data_release(fontSettings)
            end

            -- Apply the updated settings to the source
            obs.obs_source_update(textSource, settings)
            obs.obs_data_release(settings)
            obs.obs_source_release(textSource)
        end
    end
end

-- Function to show or hide the logos depending on the selected radio button
function updateLogoVisibilities(logoOption)
    -- Loop through each scene
    for _, sceneSource in ipairs(obs.obs_frontend_get_scenes()) do
        local scene = obs.obs_scene_from_source(sceneSource)

        -- Get the scene item for XTDB logo
        local xtdb_item = obs.obs_scene_find_source(scene, xtdbLogo)

        -- Get the scene item for JUXT logo
        local juxt_item = obs.obs_scene_find_source(scene, juxtLogo)

        -- Check which logo option is selected and set visibility
        if logoOption == "JUXT" then
            if juxt_item then
                obs.obs_sceneitem_set_visible(juxt_item, true)  -- Show JUXT logo
            end
            if xtdb_item then
                obs.obs_sceneitem_set_visible(xtdb_item, false)  -- Hide XTDB logo
            end
        elseif logoOption == "XTDB" then
            if juxt_item then
                obs.obs_sceneitem_set_visible(juxt_item, false)  -- Hide JUXT logo
            end
            if xtdb_item then
                obs.obs_sceneitem_set_visible(xtdb_item, true)  -- Show XTDB logo
            end
        end

        -- Release the scene source
        obs.obs_source_release(sceneSource)
    end
end

-- Called when the user clicks Apply or updates settings in the script
function script_update(settings)
    -- Switch to JUXT scene collection if not already active
    switchToJUXTCollection()

    -- Get the folder path from user input
    folderPath = obs.obs_data_get_string(settings, "folderPath")
    
    -- Update text input from user
    textInputs[1] = obs.obs_data_get_string(settings, "titleInput")
    textInputs[2] = obs.obs_data_get_string(settings, "subtitleInput")
    textInputs[3] = obs.obs_data_get_string(settings, "nameInput")
    textInputs[4] = obs.obs_data_get_string(settings, "jobTitleInput")

    -- Get the selected logo option (JUXT or XTDB)
    local logoOption = obs.obs_data_get_string(settings, "logoChoice")

    -- Update sources with new data
    updateImageSources()
    applyRoundingToCamera()
    updateText()

    -- Now use the function to update logo visibility based on the selected option
    updateLogoVisibilities(logoOption)
end

-- UI elements in the OBS script window
function script_properties()
  local props = obs.obs_properties_create()

  -- Folder selection for images
  obs.obs_properties_add_path(props, "folderPath", "Select Image Folder", obs.OBS_PATH_DIRECTORY, "", folderPath)

  -- Multiline text input fields for title, subtitle, name, and job title
  obs.obs_properties_add_text(props, "titleInput", "Title", obs.OBS_TEXT_MULTILINE)
  obs.obs_properties_add_text(props, "subtitleInput", "Subtitle", obs.OBS_TEXT_MULTILINE)
  obs.obs_properties_add_text(props, "nameInput", "Name", obs.OBS_TEXT_DEFAULT)
  obs.obs_properties_add_text(props, "jobTitleInput", "Job Title", obs.OBS_TEXT_DEFAULT)

  -- Radio buttons for logo selection (JUXT or XTDB)
  local logoChoice = obs.obs_properties_add_list(props, "logoChoice", "Are you producing content for JUXT or XTDB?", obs.OBS_COMBO_TYPE_LIST, obs.OBS_COMBO_FORMAT_STRING)
  obs.obs_property_list_add_string(logoChoice, "JUXT", "JUXT")
  obs.obs_property_list_add_string(logoChoice, "XTDB", "XTDB")

  return props
end


-- Description of the script
function script_description() 
    return [[
        This script automates the following actions:
        1. Switches to the "JUXT" scene collection if not already active.
        2. Allows the user to select a folder containing images for predefined image sources.
        3. Updates image sources with files from the folder.
        4. Applies a Image Mask/Blend filter to two camera sources.
        5. Updates four text sources with input from the user and applies specific font sizes.
        6. Shows or hides the JUXT or XTDB logos based on the selected option.
    ]]
end
